<div class="bg-primary px-2 py-2">
    <a href="{{ route('blogs') }}"><h5>BLOG</h5></a>

<br> <hr>
<a href="{{ route('terms') }}"><h6>Terms And Conditions</h6></a>
</div>
