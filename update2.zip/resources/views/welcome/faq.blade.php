@extends('welcome.layouts.welcomeMaster')

@push('css')
@endpush

@section('content')



@include('welcome.parts.faq')

@endsection

@push('js')
<script type="text/javascript">  
</script>
@endpush