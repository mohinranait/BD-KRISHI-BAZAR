  <section id="subintro">
    <div class="jumbotron subhead" id="overview">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h3> Easy Way Automation</h3>
            <p>সহজ করে  সেলেনিয়াম শিখি....</p>
          </div>
          <div class="span4">
            <div class="input-append">
              <form class="form-search">
                <input type="text" class="input-medium search-query">
                <button type="submit" class="btn btn-inverse">Search</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="maincontent">
    <div class="container">
      <div class="row">
        <div class="span12">
          <h2>Our Paid Course</h2>

          <div class="row">
            <div class="span3">
              <div class="well well-primary">
                <h2>Cucumber</h2>
               
                <p><span class="label">Schedule</span></p>
                <ul class="check-white">
                  <li>Total Hours 100 hours</li>
                  <li>Unlimited access with no limits</li>
                  <li>Interview Questions and Answare </li>
                  <li>Resume support</li>
                  <li>Real Time Project</li>
                </ul>

                <h3>$20.99 / month</h3>
                <p><a class="btn btn-large" href="#"><i class="icon-ok icon"></i> Pay here</a></p>
              </div>
            </div>

            <div class="span3">
              <div class="well well-warning">
                <h2>TestNG</h2>
                <p><span class="label">Schedule</span></p>
                <ul class="check-white">
                  <li>Total Hours 100 hours</li>
                  <li>Unlimited access with no limits</li>
                  <li>Interview Questions and Answare </li>
                  <li>Resume support</li>
                  <li>Real Time Project</li>
                </ul>

                <h3>$20.99 / month</h3>
                <p><a class="btn btn-large" href="#"><i class="icon-ok icon"></i> Pay here</a></p>
              </div>
            </div>

            <div class="span3">
              <div class="well well-info">
                <h2>Robotic</h2>
                <p><span class="label">Schedule</span></p>
                <ul class="check-white">
                  <li>Total Hours 100 hours</li>
                  <li>Unlimited access with no limits</li>
                  <li>Interview Questions and Answare </li>
                  <li>Resume support</li>
                  <li>Real Time Project</li>
                </ul>

                <h3>$20.99 / month</h3>
                <p><a class="btn btn-large" href="#"><i class="icon-ok icon"></i> Pay here</a></p>
              </div>
            </div>

            <div class="span3">
              <div class="well well-success">
                <h2>Api</h2>
                <p><span class="label">Schedule</span></p>
                <ul class="check-white">
                  <li>Total Hours 100 hours</li>
                  <li>Unlimited access with no limits</li>
                  <li>Interview Questions and Answare </li>
                  <li>Resume support</li>
                  <li>Real Time Project</li>
                </ul>

                <h3>$20.99 / month</h3>
                <p><a class="btn btn-large" href="#"><i class="icon-ok icon"></i> Pay here</a></p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </section>