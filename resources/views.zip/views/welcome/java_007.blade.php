@extends('welcome.layouts.welcomeMaster')

@push('css')
@endpush

@section('content')



@include('welcome.parts.java_007')

@endsection

@push('js')
<script type="text/javascript">  
</script>
@endpush
