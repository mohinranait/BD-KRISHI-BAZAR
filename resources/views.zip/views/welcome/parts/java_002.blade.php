  <section id="subintro">
    <div class="jumbotron subhead" id="overview">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h3> Easy Way Automation</h3>
            <p>সহজ করে  সেলেনিয়াম শিখি....</p>
          </div>
          <div class="span4">
            <div class="input-append">
              <form class="form-search">
                <input type="text" class="input-medium search-query">
                <button type="submit" class="btn btn-inverse">Search</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="maincontent">
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="half-width">
            <img src="images/profile1.png" alt="">
           
        </div>
        <div class="half-width">
            <h2>National Visa Center</h2>
        </div>

        <div id="full-stack" class="half-width">
            <label for="Student_Name">F_Name:</label>
            <input type="text" id="Student_Name" name="Student_Name"><br><br>
            <label for="Course_Name">Country: </label>
            <input type="text" id="Course_Name" name="Course_Name"><br><br>
            <label for="Phone_Number">Amount:</label>
            <input type="text" id="Amnt" name="Amnt"><br><br>
            <p>Please <b>Select</b> your gender:</p>
            <input type="radio" id="male" name="gender" value="male">
            <label for="male">Male</label><br>
            <input type="radio" id="female" name="gender" value="female">
            <label for="female">Female</label>
            <br></br>
        </div>

        <!--<div class="sajib">-->
        <!--    <img src="images/sajib.png" alt="">-->
        <!--</div>-->

        <div id="full-stack" class="half-width">
           
            <label for="cars">Date of issue :</label>
            <select name="batch" id="batch">
                <option value="s_3">Week_01</option>
                <option value="s_4">Week_02</option>
                <option value="s_5">Week_03</option>
                <option value="s_6">Week_04</option>
            </select>
             <br>
            

             <!--<div class="container">-->
                                   
             <!--   <div class="dropdown">-->
             <!--     <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Dropdown Example-->
             <!--     <span class="caret"></span></button>-->
             <!--     <ul class="dropdown-menu">-->
             <!--       <li><a href="#">Week_01</a></li>-->
             <!--       <li><a href="#">Week_02</a></li>-->
             <!--       <li><a href="#">Week_03</a></li>-->
             <!--     </ul>-->
             <!--   </div>-->
             <!-- </div>-->
             <!-- <br>-->
         <p>Upload Your Document :</p>
         <label for="Driving">Driving License      : </label>
         <input type="file" id="driving" name="Driving">
          <br></br>
          <label for="Birth">Birth Certificate      : </label>
          <input type="file" id="birth" name="Birth">
          <br></br>
          <label for="Birth">Tax Return 1099      : </label>
          <input type="file" id="tax" name="tax">
          <br></br>
          <input type="submit" value="Submit"  >
          </div>

        </div>
      </div>

    </div>
  </section>