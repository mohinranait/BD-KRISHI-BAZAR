  <section id="subintro">
    <div class="jumbotron subhead" id="overview">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h3> Easy Way Automation</h3>
            <p>সহজ করে  সেলেনিয়াম শিখি....</p>
          </div>
          <div class="span4">
            <div class="input-append">
              <form class="form-search">
                <input type="text" class="input-medium search-query">
                <button type="submit" class="btn btn-inverse">Search</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
 
  <section id="maincontent">
    <div class="container">
      <div class="row">
        <div class="span12">
          <!-- <h2>basic</h2> -->

          <div class="row">
            <div style="margin-bottom: -20px;" class="span12">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                <h2 style="color: black; text-align: center;">Get attri by WebElement</h2>
                <!-- <h3 style="color: black; text-align: center;">Get Attribute by WebElement</h3> -->
              </div>
              </a>
            </div>

          
          </div>

          <div class="row">

            <!-- first div -->
            <div style="margin-bottom: 20px;" class="span12">
              <a style="text-decoration: none;" href="#">
                <div style="padding: 4px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: white;" class="well-primary">
                 <h6 style="color: black; text-align: center;">.getAttribute();</h6>
                 <p style="text-align: center;"><a class="btn btn-large" href="#"><i class="icon-ok icon"></i> click to see the date and time</a></p>
              </div>
              </a>

            </div>
<br>
            <div class="span12">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                <h2 style="color: black; text-align: center;">Get attri by WebElement</h2>
                <!-- <h3 style="color: black; text-align: center;">Get Attribute by WebElement</h3> -->
              </div>
              </a>
            </div>
<br>
            <div style="margin-bottom: 20px;" class="span12">
              <a style="text-decoration: none;" href="#">
                <div style="padding: 4px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: black;" class="well-primary">
                 <h6 style="color: black; text-align: center;">.getAttribute();</h6>
                 <select style="width: 100%; height: calc(2.25rem + 2px); padding: inherit; line-height: 1.5; color: #495057; vertical-align: middle; background-size: 8px 10px; border: 1px solid #ced4da; border-radius: .25rem; appearance: none;" class="custom-select" name="DemoDropDown">                                                
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="0">C#</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="1">Python</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="2">Java</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="3">PHP</option>
                     </select>
<br>
                     <select style="width: 100%; height: calc(2.25rem + 2px); padding: inherit; line-height: 1.5; color: #495057; vertical-align: middle; background-size: 8px 10px; border: 1px solid #ced4da; border-radius: .25rem; appearance: none;" class="custom-select" name="DemoDropDown">                                                
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="0">C#</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="1">Python</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="2">Java</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="3">PHP</option>
                     </select>
              </div>
              </a>

            </div>

<!-- radio start -->
<br>
      <div class="span12">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                <h2 style="color: black; text-align: center;">Get attri by WebElement</h2>
                <!-- <h3 style="color: black; text-align: center;">Get Attribute by WebElement</h3> -->
              </div>
              </a>
            </div>
<br>
            <div style="margin-bottom: 20px;" class="span12">
              <a style="text-decoration: none;" href="#">
                <div style="padding: 4px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: black;" class="well-primary">
                 <h6 style="color: black; text-align: center;">.getAttribute();</h6>
                 <select style="width: 100%; height: calc(2.25rem + 2px); padding: inherit; line-height: 1.5; color: #495057; vertical-align: middle; background-size: 8px 10px; border: 1px solid #ced4da; border-radius: .25rem; appearance: none;" class="custom-select" name="DemoDropDown">                                                
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="0">C#</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="1">Python</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="2">Java</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="3">PHP</option>
                     </select>
<br>
                     <select style="width: 100%; height: calc(2.25rem + 2px); padding: inherit; line-height: 1.5; color: #495057; vertical-align: middle; background-size: 8px 10px; border: 1px solid #ced4da; border-radius: .25rem; appearance: none;" class="custom-select" name="DemoDropDown">                                                
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="0">C#</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="1">Python</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="2">Java</option>
                         <option style="font-weight: normal; display: block; white-space: pre; min-height: 1.2em; padding: 0px 2px 1px;" value="3">PHP</option>
                     </select>
              </div>
              </a>

            </div>  

             <!-- radio close -->

  <!-- table start -->
<div class="span12">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                <h2 style="color: black; text-align: center;">Get attri by WebElement</h2>
              </div>
              </a>
            </div>

                <div class="span12">
                  <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                    <table style="width:100%">
                      <tr>
                        <th style="border-style: solid; border-color: black; border-radius: 5px; margin-right: 12px;">
                          <div class="h">
                             <h6 style="color: black; text-align: center;">.getAttribute();</h6>
                             <p style="text-align: center;"><a class="btn btn-large" href="#"><i class="icon-ok icon"></i> click to see the date and time</a></p>
                          </div>
                        </th>
                        <th style="border-style: solid; border-color: black; border-radius: 5px; margin-right: 12px;">
                          <div class="h">
                             <h6 style="color: black; text-align: center;">.getAttribute();</h6>
                             <p style="text-align: center;"><a class="btn btn-large" href="#"><i class="icon-ok icon"></i> click to see the date and time</a></p>
                          </div>
                        </th>
                      </tr>
                    </table>
                  </div>
                  </a>
                </div>  


<!-- xpath -->
<!-- 
<div class="span12">
<div id="mBody">

<div class="mbContainer">
<div class="mbWrapper">
  <h1>XPATH [Relationship]:</h1>
    <div class="box">
        <div class="bHeadline">
          <h4><i>Xpath relationship is like finding element by parent, child, sibling, ancestor etc.</i></h4>
        </div>
        <div class="bPart">
          <div class="bpLeft">
            <font>
              Core Java

            </font>
            <p>
              Click enroll button below to enroll for Live Java Training

            </p>
            <button>
              Enroll

            </button>

          </div>
          <div class="bpRight">
            <font>
              Selenium WebDriver

            </font>
            <p>
              Click enroll button below to enroll for Live Selenium Training

            </p>
            <button>
              Enroll

            </button>


          </div>


        </div>

    </div>

</div>
</div>
</div>
</div> -->

<!-- xpath end -->

<!-- red st -->
<div style="margin-top: 22px;" class="span12">
<div id="mBody">

<div class="mbContainer">
<div class="mbWrapper">
    <div class="box">
        <div class="bHeadline">
          <h4><mark style="background-color: #FFF8DC;">Perform mouse over to button below by Actions class:</mark></h4>
        </div>
        <div class="bPart">
  
    <div class="span2">
      
    </div>
    <div class="span6">
      <div class="widget">
            <h2 id="mouseovertext">Red means danger</h2>
            
            <ul class="social_small">
              <button style="background-color: red; padding: 15px; font-size: 15px;" onmouseover="document.getElementById('mouseovertext').textContent='Red means danger'">
              Mouse over on me

            </button>
            <button style="background-color: green; padding: 15px; font-size: 15px;" onmouseover="document.getElementById('mouseovertext').textContent='Green for Go..'">
              Mouse over on me

            </button>
            <button style="background-color: #009cea; padding: 15px; font-size: 15px;" onmouseover="document.getElementById('mouseovertext').textContent='Sky is Blue'">
              Mouse over on me

            </button>
            </ul>
          </div>
    </div>
    <div class="span4">
      
    </div>




        </div>

    </div>

</div>
</div>
</div>
</div>
<!-- red end -->


<!-- table end -->


<!-- perform start -->
<!-- <div class="mBody">                  
                  
                     <h5>Perform mouse over to button below by Actions class:</h5>
 
                                   <div class="mbContainer">
                                       <h1 id="mouseovertext">Red means danger</h1>
                                   </div>
                                    <ul class="col col-md-12 text-center mt-md-4">
                              
                                    
                                    <li onmouseover="document.getElementById('mouseovertext').textContent='Red means danger'" class="col col-md-4 d-inline p-3 m-2 bg-danger text-white">Mouse over on me </li>
                                    <li onmouseover="document.getElementById('mouseovertext').textContent='Green for Go..'" class="col col-md-4 d-inline p-3 m-2 bg-success text-white">Mouse over on me </li>               <li onmouseover="document.getElementById('mouseovertext').textContent='Sky is Blue'" class="col col-md-4 d-inline p-3 m-2 bg-primary text-white">Mouse over on me </li>
                                    
                                </ul>
                 </div> -->
<!-- perform end -->

<!-- Actions object demo start -->

<!-- Actions object demo end -->

            <!-- <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: #333;" class="well-primary">
                <h6 style="color: yellow; text-align: center;">.getAttribute();</h6>
              </div>
              </a>
            </div> -->
          </div>

         

        </div>
      </div>

    </div>
  </section>