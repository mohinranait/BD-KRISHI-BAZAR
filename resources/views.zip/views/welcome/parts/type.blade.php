  <section id="subintro">
    <div class="jumbotron subhead" id="overview">
      <div class="container">
        <div class="row">
          <div class="span8">
            <h3> Easy Way Automation</h3>
            <p>সহজ করে  সেলেনিয়াম শিখি....</p>
          </div>
          <div class="span4">
            <div class="input-append">
              <form class="form-search">
                <input type="text" class="input-medium search-query">
                <button type="submit" class="btn btn-inverse">Search</button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section id="maincontent">
    <div class="container">
      <div class="row">
        <div class="span12">
          <!-- <h2>basic</h2> -->

          <div class="row">
            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                <h2 style="color: black; text-align: center;">Type Text by WebElement</h2>
              </div>
              </a>
            </div>

            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                <h2 style="color: black; text-align: center;">Type Text by JavaScript</h2>
              </div>
              </a>
            </div>

            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: center; border-style: solid; border-color: black; border-radius: 5px; background-color: #ffbb00;" class="well-primary">
                <h2 style="color: black; text-align: center;">Type Text by Corordinate</h2>
              </div>
              </a>
            </div>
          </div>

          <div class="row">
            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: #333;" class="well-primary">
                 <h6 style="color: yellow; text-align: center;">.sendKeys("Type your 1");</h6>
              </div>
              </a>
            </div>

            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: #333;" class="well-primary">
                 <h6 style="color: yellow; text-align: center;">
                 .sendKeys("Type your 2");</h6>
              </div>
              </a>
            </div>

            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 4px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: #333;" class="well-primary">
                <h6 style="color: yellow; text-align: center;">.sendKeys("Type your 3");</h6>
              </div>
              </a>
            </div>
          </div>

          <div class="row">
            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 50px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: #333;" class="well-primary">
             
             <ol type="1">
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
           </ol>  
              </div>
              </a>
            </div>

            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 50px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: #333;" class="well-primary">
             
             <ol type="1">
                   <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                  
          </ol>  
              </div>
              </a>
            </div>

            <div class="span4">
              <a style="text-decoration: none;" href="#"><div style="padding: 50px; text-align: left; border-style: solid; border-color: black; border-radius: 5px; background-color: #333;" class="well-primary">
             
             <ol type="1">
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                    <li><p style="color: white; text-align: left;">আমরা দেখবো কিভাবে টাইপ করতে হয়। </p></li>
                  
          </ol>  
              </div>
              </a>
            </div>
          </div>

        </div>
      </div>

    </div>
  </section>