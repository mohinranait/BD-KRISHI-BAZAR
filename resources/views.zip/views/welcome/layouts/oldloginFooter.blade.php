<div class="container">
    <div style="background-color: #7cbb00;" class="row justify-content-center">
        <div class="col-md-4">
            <div style="padding: 15px; color: white;" class="widget">
            <h4>About us</h4>
            <address>
          <strong>Tech heron file.</strong><br>
         <!--  2409 E Tremont CT<br>
          Richmond, VA 223200<br>
          <abbr title="Phone">P:</abbr> 571-403-4587 -->
          </address>

            <address>
          <strong>Contact us</strong><br>
          <a style="color: white;" href="mailto:#">info@file.techheron.com</a>
          </address>
          </div>
        </div>

        <div class="col-md-4">
            <div style="padding: 15px; color: white;" class="widget">
          <!--   <h4>Browse pages</h4>
            <ul class="nav nav-list regular">
              <li class="nav-header"><a style="color: white;" href="{{ url('/') }}">Easy Way Automation</a></li>
     
              <li><a href="#"></a></li>
              
            </ul> -->
          </div>
        </div>

        <div class="col-md-4">
            <div style="padding: 15px; color: white;" class="widget">
            <!-- <h4>Get email updates</h4>
            <form class="form-horizontal" action="#" method="post">
              <fieldset>
                <p>
                  Sign up for email updates 
                </p>

                <div class="input-prepend input-append">
                  <input class="form-control" id="appendedPrependedInput" type="text" placeholder="Email"><br>
                  <button m class="btn btn-primary" type="submit">Subscribe!</button>
                </div>
              </fieldset>
            </form> -->
          </div>
        </div>
    </div>

    <!-- footer 2 -->
    <div class="row justify-content-center">
        <div class="col-md-4">
           <p style="padding: 5px;">&copy; Tech Heron - All right reserved</p>
        </div>

        <div class="col-md-4">
           
        </div>

        <div class="col-md-4">
            <p style="padding: 5px;"> Designed by <a href="https://webseobd.com/">Web SEO BD</a></p>
        </div>
    </div>
</div>