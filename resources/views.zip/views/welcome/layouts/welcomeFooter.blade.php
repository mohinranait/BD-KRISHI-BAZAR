
  <footer class="footer">
      <div class="container">
          <div class="row">



            <div class="col-md-3">
                <div style="background-color: #7cbb00; height: 220px; width: 250px; padding: 20px;" class="card">
                    <div class="w3-card-body">

            <h4>About us</h4>
        
          <strong>Tech heron file.</strong><br>
      
<br>
         
          <strong>Contact us</strong><br>
          <a style="color: white;" href="mailto:#">file@techheron.com</a>
         
          
   
                    </div>
                </div>
                <br>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="w3-card-body">
                       <a href="/register"> <img src="{{asset('img/g1.png')}}" alt="" class="img-fluid"></a>
                    </div>
                </div>
                <br>
            </div>

            <div class="col-md-3">
                <div class="card">
                    <div class="w3-card-body">
                       <a href="/register"> <img src="{{asset('img/ad1.png')}}" alt="" class="img-fluid"></a>
                    </div>
                </div>
                <br>
            </div>

            <div class="col-md-3">
                <div class="card">
                    <div class="w3-card-body">
                       <a href="/register"> <img src="{{asset('img/w1.png')}}" alt="" class="img-fluid"></a>
                    </div>
                </div>
            </div>


          </div>
      </div>

      <div class="verybottom" style="max-height: 50px">
          <div class="container">
              <div class="row">
                  <div class="col-md-6">
                      <p style="padding: 5px;">&copy; Tech Heron - All right reserved</p>
                  </div>
                  <div class="col-md-6">
                      <div class="text-right">
                          <div class="credits">
                              <!--
                  All the links in the footer should remain intact.
                  You can delete the links only if you purchased the pro version.
                  Licensing information: https://bootstrapmade.com/license/
                  Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=Scaffold
                -->
                               <p style="padding: 5px;"> Designed by <a href="https://webseobd.com/">Web SEO BD</a></p>

                          </div>
                      </div>
                  </div>
              </div>
          </div>

      </div>
  </footer>
