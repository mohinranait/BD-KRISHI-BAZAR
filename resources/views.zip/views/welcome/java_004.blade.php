@extends('welcome.layouts.welcomeMaster')

@push('css')
@endpush

@section('content')



@include('welcome.parts.java_004')

@endsection

@push('js')
<script type="text/javascript">  
</script>
@endpush
