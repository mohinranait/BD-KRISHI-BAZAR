@extends('welcome.layouts.welcomeMaster')

@push('css')
@endpush

@section('content')



@include('welcome.parts.selenium')

@endsection

@push('js')
<script type="text/javascript">  
</script>
@endpush