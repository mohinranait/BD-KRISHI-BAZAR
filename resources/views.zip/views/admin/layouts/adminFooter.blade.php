<footer class="main-footer">
    <strong>Copyright &copy; {{ date('Y') }} <a href="#">Hello</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.3
    </div>
  </footer>