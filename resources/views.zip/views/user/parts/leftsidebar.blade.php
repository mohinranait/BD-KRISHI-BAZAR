<div class="row">
    <div class="col-12" style="border-bottom: 1px solid gray">
        <a href="{{route('user.myPost')}}">My Ads</a>
    </div>
</div>
<div class="row">
    <div class="col-12" style="border-bottom: 1px solid gray">
        My Account
    </div>
</div>
<div class="row">
    <div class="col-12" style="border-bottom: 1px solid gray; ">
      My Account
    </div>
</div>
<div class="row">
    <div class="col-12" style="border-bottom: 1px solid gray">
        My Account
    </div>
</div>
